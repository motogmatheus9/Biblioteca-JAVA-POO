package biblioteca.padroes;

/**
 * Tipos de usuário aceitos pela fábrica.
 */
public enum TipoUsuario {
    ALUNO,
    PROFESSOR
}