package biblioteca.padroes;

/**
 * Estratégia para cálculo de multa por atraso.
 */
public interface MultaStrategy {
    /**
     * Calcula valor da multa por dias em atraso.
     *
     * @param diasAtraso quantidade de dias em atraso
     * @return valor da multa
     */
    double calcularMulta(int diasAtraso);
}