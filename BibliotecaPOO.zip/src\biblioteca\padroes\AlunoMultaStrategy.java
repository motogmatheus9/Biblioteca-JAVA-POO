package biblioteca.padroes;

/**
 * Estratégia de multa para alunos.
 */
public class AlunoMultaStrategy implements MultaStrategy {
    private static final double VALOR_DIA = 1.0;

    @Override
    public double calcularMulta(int diasAtraso) {
        return Math.max(0, diasAtraso) * VALOR_DIA;
    }
}