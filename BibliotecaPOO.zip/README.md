# BibliotecaPOO

Sistema de Gerenciamento de Biblioteca em Java (POO), pronto para importação no Eclipse.

## Requisitos atendidos e mapeamento

### 1) Classes básicas
- `Livro` com atributos privados, getters/setters e construtores sobrecarregados com `this(...)`: `src/biblioteca/modelo/Livro.java`
- `Usuario` abstrata com atributos privados, `List<Emprestimo>` e construtores sobrecarregados: `src/biblioteca/modelo/Usuario.java`
- `Emprestimo` com `livro`, `usuario`, `dataEmprestimo`, `dataDevolucaoPrevista`, `dataDevolucaoReal`: `src/biblioteca/modelo/Emprestimo.java`

### 2) Encapsulamento total
- Todos os atributos privados e acesso por getters/setters em `src/biblioteca/modelo/*` e `src/biblioteca/padroes/Biblioteca.java`

### 3) Relacionamentos
- Associação `Usuario`-`Livro` via `Emprestimo`: `src/biblioteca/modelo/Emprestimo.java`
- Composição: `Usuario` gerencia `emprestimosAtivos`: `src/biblioteca/modelo/Usuario.java`
- Agregação: `Biblioteca` agrega `ArrayList<Livro>`: `src/biblioteca/padroes/Biblioteca.java`

### 4) Herança/Polimorfismo
- `Usuario` base e subclasses `Aluno`/`Professor`: `src/biblioteca/modelo/Aluno.java`, `src/biblioteca/modelo/Professor.java`
- Método polimórfico `calcularPrazoMaximo()`:
  - Aluno = 14 dias
  - Professor = 30 dias

### 5) Abstratas/Interfaces
- `IPesquisavel` com `buscarPorTitulo` e `buscarPorAutor`: `src/biblioteca/interfaces/IPesquisavel.java`
- `RecursoBiblioteca` abstrata: `src/biblioteca/modelo/RecursoBiblioteca.java`
- `Biblioteca implements IPesquisavel`: `src/biblioteca/padroes/Biblioteca.java`

### 6) Exceções personalizadas + try/catch real
- `LivroIndisponivelException`: `src/biblioteca/excecoes/LivroIndisponivelException.java`
- `UsuarioInadimplenteException`: `src/biblioteca/excecoes/UsuarioInadimplenteException.java`
- `LimiteEmprestimosExcedidoException`: `src/biblioteca/excecoes/LimiteEmprestimosExcedidoException.java`
- `try/catch` no menu de empréstimo/devolução: `src/biblioteca/Main.java`

### 7) Coleções
- `ArrayList<Livro>`, `ArrayList<Usuario>`, `HashMap<String, Livro>`: `src/biblioteca/padroes/Biblioteca.java`

### 8) Padrões
- Singleton: `Biblioteca.getInstancia()`: `src/biblioteca/padroes/Biblioteca.java`
- Factory: `UsuarioFactory.criar(...)`: `src/biblioteca/padroes/UsuarioFactory.java`
- Strategy:
  - `MultaStrategy`: `src/biblioteca/padroes/MultaStrategy.java`
  - `AlunoMultaStrategy` (R$1,00/dia): `src/biblioteca/padroes/AlunoMultaStrategy.java`
  - `ProfessorMultaStrategy` (R$0,50/dia): `src/biblioteca/padroes/ProfessorMultaStrategy.java`
  - Exposição em `Usuario` subclasses via `getMultaStrategy()`: `src/biblioteca/modelo/Aluno.java`, `src/biblioteca/modelo/Professor.java`

## Pré-carga no startup
- 4 livros + 1 aluno + 1 professor em `preloadDados()`: `src/biblioteca/Main.java`

## Compilação (Windows PowerShell)
```powershell
javac -d bin (Get-ChildItem -Recurse -Path .\src -Filter *.java | ForEach-Object { $_.FullName })
```

## Execução
```powershell
java -cp bin biblioteca.Main
```

## Importar no Eclipse
1. `File > Import...`
2. `General > Existing Projects into Workspace`
3. Selecione a pasta `BibliotecaPOO`
4. Clique em `Finish`
5. Execute `src/biblioteca/Main.java` com `Run As > Java Application`
