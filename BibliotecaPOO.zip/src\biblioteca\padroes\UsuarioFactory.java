package biblioteca.padroes;

import biblioteca.modelo.Aluno;
import biblioteca.modelo.Professor;
import biblioteca.modelo.Usuario;

/**
 * Fábrica para criação de usuários por tipo.
 */
public class UsuarioFactory {
    /**
     * Cria usuário por tipo.
     *
     * @param tipo tipo do usuário
     * @param nome nome
     * @param matricula matrícula
     * @param email e-mail
     * @param extra curso (aluno) ou departamento (professor)
     * @return usuário criado
     */
    public static Usuario criar(TipoUsuario tipo, String nome, String matricula, String email, String extra) {
        if (tipo == TipoUsuario.ALUNO) {
            return new Aluno(nome, matricula, email, extra);
        }
        return new Professor(nome, matricula, email, extra);
    }
}