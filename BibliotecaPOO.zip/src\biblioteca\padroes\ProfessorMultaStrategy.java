package biblioteca.padroes;

/**
 * Estratégia de multa para professores.
 */
public class ProfessorMultaStrategy implements MultaStrategy {
    private static final double VALOR_DIA = 0.5;

    @Override
    public double calcularMulta(int diasAtraso) {
        return Math.max(0, diasAtraso) * VALOR_DIA;
    }
}