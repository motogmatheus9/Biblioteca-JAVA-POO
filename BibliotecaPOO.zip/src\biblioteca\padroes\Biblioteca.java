package biblioteca.padroes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import biblioteca.excecoes.LimiteEmprestimosExcedidoException;
import biblioteca.excecoes.LivroIndisponivelException;
import biblioteca.excecoes.UsuarioInadimplenteException;
import biblioteca.interfaces.IPesquisavel;
import biblioteca.modelo.Emprestimo;
import biblioteca.modelo.Livro;
import biblioteca.modelo.Usuario;

/**
 * Classe central da biblioteca (Singleton).
 */
public class Biblioteca implements IPesquisavel {
    private static final Biblioteca INSTANCIA = new Biblioteca();

    private ArrayList<Livro> livros;
    private ArrayList<Usuario> usuarios;
    private HashMap<String, Livro> livrosPorIsbn;
    private ArrayList<Emprestimo> historicoEmprestimos;

    private Biblioteca() {
        this.livros = new ArrayList<>();
        this.usuarios = new ArrayList<>();
        this.livrosPorIsbn = new HashMap<>();
        this.historicoEmprestimos = new ArrayList<>();
    }

    /**
     * Obtém instância única da biblioteca.
     *
     * @return instância singleton
     */
    public static Biblioteca getInstancia() {
        return INSTANCIA;
    }

    public ArrayList<Livro> getLivros() {
        return livros;
    }

    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public ArrayList<Emprestimo> getHistoricoEmprestimos() {
        return historicoEmprestimos;
    }

    /**
     * Cadastra um livro na coleção.
     *
     * @param livro livro a cadastrar
     */
    public void cadastrarLivro(Livro livro) {
        livros.add(livro);
        livrosPorIsbn.put(livro.getIsbn(), livro);
    }

    /**
     * Busca livro por ISBN.
     *
     * @param isbn ISBN
     * @return livro encontrado ou null
     */
    public Livro buscarPorIsbn(String isbn) {
        return livrosPorIsbn.get(isbn);
    }

    /**
     * Atualiza dados do livro pelo ISBN.
     *
     * @param isbn ISBN de referência
     * @param novo livro com novos dados
     * @return true se atualizou
     */
    public boolean atualizarLivro(String isbn, Livro novo) {
        Livro antigo = livrosPorIsbn.get(isbn);
        if (antigo == null) {
            return false;
        }
        antigo.setTitulo(novo.getTitulo());
        antigo.setAutor(novo.getAutor());
        antigo.setAnoPublicacao(novo.getAnoPublicacao());
        antigo.setQuantidadeDisponivel(novo.getQuantidadeDisponivel());
        if (!isbn.equals(novo.getIsbn())) {
            livrosPorIsbn.remove(isbn);
            antigo.setIsbn(novo.getIsbn());
            livrosPorIsbn.put(antigo.getIsbn(), antigo);
        }
        return true;
    }

    /**
     * Remove livro se não estiver emprestado.
     *
     * @param isbn ISBN
     * @return true se removeu
     */
    public boolean removerLivro(String isbn) {
        Livro livro = livrosPorIsbn.get(isbn);
        if (livro == null) {
            return false;
        }
        for (Emprestimo e : historicoEmprestimos) {
            if (e.getLivro().getIsbn().equals(isbn) && e.getDataDevolucaoReal() == null) {
                return false;
            }
        }
        livros.remove(livro);
        livrosPorIsbn.remove(isbn);
        return true;
    }

    /**
     * Cadastra usuário.
     *
     * @param usuario usuário
     */
    public void cadastrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    /**
     * Busca usuário por matrícula.
     *
     * @param matricula matrícula
     * @return usuário ou null
     */
    public Usuario buscarUsuarioPorMatricula(String matricula) {
        for (Usuario usuario : usuarios) {
            if (usuario.getMatricula().equalsIgnoreCase(matricula)) {
                return usuario;
            }
        }
        return null;
    }

    /**
     * Atualiza dados de usuário por matrícula.
     *
     * @param matricula matrícula de referência
     * @param nome novo nome
     * @param email novo e-mail
     * @param extra novo curso/departamento
     * @return true se atualizou
     */
    public boolean atualizarUsuario(String matricula, String nome, String email, String extra) {
        Usuario usuario = buscarUsuarioPorMatricula(matricula);
        if (usuario == null) {
            return false;
        }
        usuario.setNome(nome);
        usuario.setEmail(email);
        if (usuario instanceof biblioteca.modelo.Aluno aluno) {
            aluno.setCurso(extra);
        } else if (usuario instanceof biblioteca.modelo.Professor professor) {
            professor.setDepartamento(extra);
        }
        return true;
    }

    /**
     * Realiza empréstimo de livro para usuário.
     *
     * @param isbn ISBN do livro
     * @param matricula matrícula do usuário
     * @return empréstimo criado
     * @throws LivroIndisponivelException sem estoque
     * @throws UsuarioInadimplenteException usuário inadimplente
     * @throws LimiteEmprestimosExcedidoException limite atingido
     */
    public Emprestimo realizarEmprestimo(String isbn, String matricula)
            throws LivroIndisponivelException, UsuarioInadimplenteException, LimiteEmprestimosExcedidoException {
        Livro livro = buscarPorIsbn(isbn);
        Usuario usuario = buscarUsuarioPorMatricula(matricula);
        if (livro == null || usuario == null) {
            return null;
        }

        if (livro.getQuantidadeDisponivel() <= 0) {
            throw new LivroIndisponivelException("Livro indisponível para empréstimo.");
        }
        if (usuario.possuiAtraso()) {
            throw new UsuarioInadimplenteException("Usuário possui empréstimo em atraso.");
        }
        if (usuario.getEmprestimosAtivos().size() >= usuario.getLimiteEmprestimos()) {
            throw new LimiteEmprestimosExcedidoException("Limite de empréstimos excedido para este usuário.");
        }

        LocalDate hoje = LocalDate.now();
        LocalDate prevista = hoje.plusDays(usuario.calcularPrazoMaximo());
        Emprestimo emprestimo = new Emprestimo(livro, usuario, hoje, prevista);
        usuario.getEmprestimosAtivos().add(emprestimo);
        historicoEmprestimos.add(emprestimo);
        livro.setQuantidadeDisponivel(livro.getQuantidadeDisponivel() - 1);
        return emprestimo;
    }

    /**
     * Realiza devolução e calcula multa por atraso.
     *
     * @param isbn ISBN do livro
     * @param matricula matrícula do usuário
     * @param dataDevolucao data de devolução real
     * @return valor da multa
     */
    public double realizarDevolucao(String isbn, String matricula, LocalDate dataDevolucao) {
        Usuario usuario = buscarUsuarioPorMatricula(matricula);
        if (usuario == null) {
            return -1.0;
        }
        Emprestimo alvo = null;
        for (Emprestimo emprestimo : usuario.getEmprestimosAtivos()) {
            if (emprestimo.getLivro().getIsbn().equals(isbn) && emprestimo.getDataDevolucaoReal() == null) {
                alvo = emprestimo;
                break;
            }
        }
        if (alvo == null) {
            return -1.0;
        }
        alvo.setDataDevolucaoReal(dataDevolucao);
        alvo.getLivro().setQuantidadeDisponivel(alvo.getLivro().getQuantidadeDisponivel() + 1);
        int diasAtraso = alvo.calcularDiasAtraso();
        double multa = usuario.getMultaStrategy().calcularMulta(diasAtraso);
        usuario.getEmprestimosAtivos().remove(alvo);
        return multa;
    }

    /**
     * Lista empréstimos ativos de todos os usuários.
     *
     * @return lista de empréstimos ativos
     */
    public List<Emprestimo> listarEmprestimosAtivos() {
        List<Emprestimo> ativos = new ArrayList<>();
        for (Emprestimo e : historicoEmprestimos) {
            if (e.getDataDevolucaoReal() == null) {
                ativos.add(e);
            }
        }
        return ativos;
    }

    @Override
    public List<Livro> buscarPorTitulo(String titulo) {
        List<Livro> resultado = new ArrayList<>();
        for (Livro livro : livros) {
            if (livro.getTitulo().toLowerCase().contains(titulo.toLowerCase())) {
                resultado.add(livro);
            }
        }
        return resultado;
    }

    @Override
    public List<Livro> buscarPorAutor(String autor) {
        List<Livro> resultado = new ArrayList<>();
        for (Livro livro : livros) {
            if (livro.getAutor().toLowerCase().contains(autor.toLowerCase())) {
                resultado.add(livro);
            }
        }
        return resultado;
    }
}